<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>aWNlbA==');

$data['ADITY'] = array ('1'=>'ADITY!192.168.1.39','ADITY@|@user2','ADITY#|#b2VjrJacmZ2bmQ==','ADITY%Cicukang.net','ADITY^Cicukang.net','ADITY&Rp','ADITY*10','ADITY(1','ADITY)','ADITY=10','ADITY@!@enable');
$data['BNPROJECT'] = array ('1'=>'BNPROJECT!103.105.107.154:2002','BNPROJECT@|@bdgdh2022','BNPROJECT#|#mpWZnJlkaGNk','BNPROJECT%Diig Hotspot','BNPROJECT^digi-hotspot.id','BNPROJECT&Rp','BNPROJECT*10','BNPROJECT(1','BNPROJECT)','BNPROJECT=5','BNPROJECT@!@enable');
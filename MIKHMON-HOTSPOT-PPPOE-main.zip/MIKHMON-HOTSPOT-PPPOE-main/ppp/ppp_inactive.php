
<?php
session_start();
error_reporting(0);
if (!isset($_SESSION["mikhmon"])) {
  header("Location:../admin.php?id=login");
  exit();
}

include("../routeros_api.class.php");
$API = new RouterosAPI();

$iphost = $_SESSION["iphost"];
$userhost = $_SESSION["userhost"];
$passwdhost = $_SESSION["passwdhost"];
$porthost = $_SESSION["porthost"];

if ($API->connect($iphost, $userhost, $passwdhost, $porthost)) {
  $pppActive = $API->comm("/ppp/active/print");
  $pppSecret = $API->comm("/ppp/secret/print");

  $activeNames = array_column($pppActive, 'name');
  $inactiveUsers = [];

  foreach ($pppSecret as $user) {
    if (!in_array($user['name'], $activeNames)) {
      $inactiveUsers[] = $user['name'];
    }
  }

  echo "<h2>PPP Inactive Users</h2>";
  echo "<ul>";
  foreach ($inactiveUsers as $user) {
    echo "<li>" . htmlspecialchars($user) . "</li>";
  }
  echo "</ul>";

  $API->disconnect();
} else {
  echo "Unable to connect to Mikrotik Router.";
}
?>
